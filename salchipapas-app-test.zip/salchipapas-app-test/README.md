# salchipapas-app
family management app

## Control version
* V1.0
  * Add optión semanal menu
  * Shopping List
    * categorization by section
    
